from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import requests
import pandas as pd
import os

def extrair_dados():
    url = "https://restcountries.com/v3.1/all"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Erro ao acessar a API: {response.status_code}")

def transformar_dados(**kwargs):
    dados = kwargs['ti'].xcom_pull(task_ids='extrair_dados')
    dados_paises = []
    for pais in dados:
        nome_comum = pais.get('name', {}).get('common', 'N/A')
        regiao = pais.get('region', 'N/A')
        area = pais.get('area', 'N/A')
        populacao = pais.get('population', 'N/A')
        moedas = ', '.join(pais.get('currencies', {}).keys()) if pais.get('currencies') else 'N/A'
        idioma = ', '.join(pais.get('languages', {}).values()) if pais.get('languages') else 'N/A'
        continentes = ', '.join(pais.get('continents', 'N/A'))
        
        dados_paises.append({
            'Nome Comum': nome_comum,
            'Regiao': regiao,
            'Area': area,
            'Populacao': populacao,
            'Moedas': moedas,
            'Idioma': idioma,
            'Continentes': continentes
        })
    
    df = pd.DataFrame(dados_paises)
    df.to_csv('/tmp/dados_tratados.csv', index=False)
    kwargs['ti'].xcom_push(key='csv_path', value='/tmp/dados_tratados.csv')

def converter_para_parquet(**kwargs):
    csv_path = kwargs['ti'].xcom_pull(task_ids='transformar_dados', key='csv_path')
    df = pd.read_csv(csv_path)
    if 'Nome Comum' in df.columns:
        df = df.sort_values(by='Nome Comum', ascending=True)
        parquet_path = '/tmp/dados_tratados.parquet'
        df.to_parquet(parquet_path, index=False)
        print(f'Arquivo salvo como {parquet_path}')
    else:
        raise Exception('Erro: A coluna "Nome Comum" não foi encontrada no arquivo.')

# Definição da DAG
with DAG(
    dag_id="dag_extrair_paises",
    schedule_interval="@daily",
    default_args={
        "start_date": datetime(2024, 1, 1),
        "retries": 1
    },
    catchup=False
) as dag:

    tarefa_extrair = PythonOperator(
        task_id='extrair_dados',
        python_callable=extrair_dados,
        do_xcom_push=True
    )
    
    tarefa_transformar = PythonOperator(
        task_id='transformar_dados',
        python_callable=transformar_dados,
        provide_context=True
    )
    
    tarefa_converter = PythonOperator(
        task_id='converter_para_parquet',
        python_callable=converter_para_parquet,
        provide_context=True
    )
    
    tarefa_extrair >> tarefa_transformar >> tarefa_converter
