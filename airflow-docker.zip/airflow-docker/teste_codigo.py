import requests
import pandas as pd

# URL da API
url = "https://restcountries.com/v3.1/all"

# Requisição GET para a API
response = requests.get(url)

# Verificação se foi bem-sucedida
if response.status_code == 200:
    # Convertendo a resposta em JSON
    dados = response.json()

    # Extraindo e tratando as informações
    dados_paises = []
    for pais in dados:
        nome_comum = pais.get('name', {}).get('common', 'N/A')
        regiao = pais.get('region', 'N/A')
        area = pais.get('area', 'N/A')
        populacao = pais.get('population', 'N/A')
        moedas = ', '.join(pais.get('currencies', {}).keys()) if pais.get('currencies') else 'N/A'
        idioma = ', '.join(pais.get('languages', {}).values()) if pais.get('languages') else 'N/A'
        continentes = ', '.join(pais.get('continents', 'N/A'))

        dados_paises.append({
            'Nome Comum': nome_comum,
            'Regiao': regiao,
            'Area': area,
            'Populacao': populacao,
            'Moedas': moedas,
            'Idioma': idioma,
            'Continentes': continentes
        })

    # Criando um DataFrame
    df = pd.DataFrame(dados_paises)

    # Ordenando a coluna "Nome Comum" em ordem alfabética
    df = df.sort_values(by='Nome Comum', ascending=True)

    # Caminhos dos arquivos
    csv_path = 'dados_tratados.csv'
    parquet_path = 'dados_tratados.parquet'

    # Salvando o DataFrame em CSV
    df.to_csv(csv_path, index=False)
    print(f"Dados salvos em '{csv_path}'")

    # Salvando o DataFrame em Parquet
    df.to_parquet(parquet_path, index=False)
    print(f"Arquivo salvo como '{parquet_path}'")

else:
    print(f"Erro ao acessar a API: {response.status_code}")
